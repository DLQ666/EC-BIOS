How to flash BIOS ROM:

1. Plug in AC adaptor.
2. Enter CMOS setup to disable "Intel Anti-Theft Technology" if the item is available.
3. Boot up and enter pure DOS environment, run Meset.exe then system will restart automatically, please enter pure DOS environment again.
4. Run flashme.bat then system will shut down automatically.
5. Plug off AC adapter for 5 seconds then plug in AC adapter.
6. Power on system and enter CMOS to check the version of BIOS.
7. To load system default, change the setting(s) if the original settings are different from system default, save change and reboot.
